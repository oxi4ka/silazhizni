<div class="header_menu">
    <a href="index.php">
        <img src="img/logo.jpg" alt="logo">
    </a>
    <nav class="top-nav">
        <a href="#" class="menu-icon" onclick="showSideMenu()"></a>
        <a href="index.php" class="nav-item">Про нас</a>
        <a href="events.php" class="nav-item">Події</a>
        <a href="specialists.php" class="nav-item">Спеціалісти</a>
        <a href="services.php" class="nav-item">Послуги</a>
        <a href="articles.php" class="nav-item">Статті</a>
        <a href="reviewes.php" class="nav-item">Відгуки</a>
        <a href="contacts.php" class="nav-item">Контакти</a>
    </nav>
    <div id="side-menu" class="side-nav">
        <a href="#" class="close" onclick="hideSideMenu()"><img src="img/close.png" alt=""></a>
        <a href="index.php">Про нас</a>
        <a href="events.php">Події</a>
        <a href="specialists.php">Спеціалісти</a>
        <a href="services.php">Послуги</a>
        <a href="articles.php">Статті</a>
        <a href="reviewes.php">Відгуки</a>
        <a href="contacts.php">Контакти</a>
    </div>
</div>