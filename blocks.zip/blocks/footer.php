<footer>
    <div class="container">
        <div class="footer_block">
            <div class="rigths">
                <a href="#">&copy2020 Все права защищены</a>
            </div>
            <div class="designed_firm">
                <a href="http://oxi4ka.com.ua/">site by <b>Web_Oxi4ka</b></a>
            </div>
            <div class="social_items">
                <a href="https://instagram.com/sila.zhizni_bc?igshid=1xvpri2mxnx0"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="https://www.facebook.com/Центр-оздоровлення-Сила-життя-1817359531607819/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
</footer>